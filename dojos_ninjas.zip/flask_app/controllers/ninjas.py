from flask import render_template, redirect, request
from flask_app import app
from flask_app.models import dojo, ninja

@app.route('/ninjas')
def ninjas():
    
    return render_template('ninja.html', dojos= dojo.Dojo.get_all())


@app.route('/create/ninja', methods=['POST'])
def create_ninja():
    ninja.Ninja.save(request.form)
    return redirect('/dojos')

@app.route('/edit/ninja/<int:id>')
def edit_ninja(id):
    #create an Object of data
    data = {
        "id":id
    }
    return render_template("edit_ninjas.html", ninja=Ninja.get_one(data))

@app.route('/update/ninja', methods=['POST'])
def update_ninja():
    Ninja.update(request.form)
    return redirect('/ninjas')

@app.route('/delete/ninja/<int:id>')
def delete_ninja(id):
    data = {
        'id':id
    }
    Ninja.delete(data)
    return redirect('/ninjas')